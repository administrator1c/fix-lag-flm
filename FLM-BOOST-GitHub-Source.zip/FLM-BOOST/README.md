# FLM BOOST – Lag Fix

Android 10+ (API 29), Java, no external runtime dependencies.

## Build APK with GitHub Actions (mobile friendly)
1. Create a new GitHub repository (choose public or private).
2. Upload the **contents** of this folder to the repository root, including `.github/workflows/build-apk.yml` (do not upload the ZIP as a single file).
3. Open **Actions** → **Build FLM BOOST APK** → **Run workflow** (or push to `main`).
4. Wait for a successful run; open it and download artifact `FLM-BOOST-debug-apk`.
5. Extract the downloaded artifact ZIP, then install `app-debug.apk` on Android.

The APK is a debug build signed automatically with a debug key. To distribute publicly, create a securely signed release build.

## Capabilities and limitations
Shows available RAM and free storage, opens FL Studio Mobile if installed, and offers Android settings shortcuts. The BOOST button refreshes device stats and gives tips. It does not claim to kill other apps, free RAM, change CPU clocks, or eliminate all audio lag. No dangerous permissions required.
